package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.Icon;
import javax.swing.ImageIcon;


public class empleados extends javax.swing.JFrame {
    public empleados() {
        initComponents();
        setSize(500, 550);
        setResizable(false);
        setTitle("Registro Ventas");
        setLocationRelativeTo(null);

        ImageIcon wallpaper = new ImageIcon("src/images/Fondo2.png");
        Icon icono = new ImageIcon(wallpaper.getImage().getScaledInstance(jLabel_Wallpaper.getWidth(), jLabel_Wallpaper.getHeight(), Image.SCALE_DEFAULT));
        jLabel_Wallpaper.setIcon(icono);
        this.repaint();

        ImageIcon wallpaper_logo = new ImageIcon("src/images/Logo.png");
        Icon icono_logo = new ImageIcon(wallpaper_logo.getImage().getScaledInstance(jLabel_logo.getWidth(), jLabel_logo.getHeight(), Image.SCALE_DEFAULT));
        jLabel_logo.setIcon(icono_logo);
        this.repaint();
    }

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }


        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton_Salir = new javax.swing.JButton();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jTextField_Producto = new javax.swing.JTextField();
        jTextField_Cantidad = new javax.swing.JTextField();
        jTextField_PrecioU = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Factura = new javax.swing.JTable();
        jComboBox_Codigo = new javax.swing.JComboBox<>();
        jLabel_Codigo = new javax.swing.JLabel();
        jLabel_Producto = new javax.swing.JLabel();
        jLabel_Cantidad = new javax.swing.JLabel();
        jLabel_PrecioU = new javax.swing.JLabel();
        jButton_Agregar = new javax.swing.JButton();
        jButton_Guardar = new javax.swing.JButton();
        jButton_Ticket = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, 30, 30));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 45, 45));

        jLabel_nameUser.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 130, 20));

        jLabel_numUser.setText("AQUI ESTA");
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 130, 20));
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, 70, 70));

        jTextField_Producto.setEditable(false);
        jTextField_Producto.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Producto.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_Producto.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Producto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Producto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Producto.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(jTextField_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, 200, 20));

        jTextField_Cantidad.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Cantidad.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_Cantidad.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Cantidad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Cantidad.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Cantidad.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 110, 20));

        jTextField_PrecioU.setEditable(false);
        jTextField_PrecioU.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_PrecioU.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_PrecioU.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_PrecioU.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_PrecioU.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_PrecioU.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(jTextField_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 230, 100, 20));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Factura.setBackground(new java.awt.Color(102, 102, 102));
        jTable_Factura.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2)));
        jTable_Factura.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jTable_Factura.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Factura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Cantidad", "Precio Unitario"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable_Factura);
        if (jTable_Factura.getColumnModel().getColumnCount() > 0) {
            jTable_Factura.getColumnModel().getColumn(0).setResizable(false);
            jTable_Factura.getColumnModel().getColumn(1).setResizable(false);
            jTable_Factura.getColumnModel().getColumn(2).setResizable(false);
            jTable_Factura.getColumnModel().getColumn(3).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, 410, 120));

        jComboBox_Codigo.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Codigo.setEditable(true);
        jComboBox_Codigo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox_Codigo.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Codigo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox_Codigo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65), new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65)));
        jComboBox_Codigo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jComboBox_Codigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_CodigoActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 110, -1));

        jLabel_Codigo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Codigo.setText("Código Producto");
        getContentPane().add(jLabel_Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        jLabel_Producto.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Producto.setText("Producto");
        getContentPane().add(jLabel_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 150, -1, 20));

        jLabel_Cantidad.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Cantidad.setText("Cantidad");
        getContentPane().add(jLabel_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, -1, -1));

        jLabel_PrecioU.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_PrecioU.setText("Precio Unitario");
        getContentPane().add(jLabel_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 210, -1, 20));

        jButton_Agregar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Agregar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Agregar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/agregar.png"))); // NOI18N
        jButton_Agregar.setText("Agregar");
        jButton_Agregar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Agregar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jButton_Agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 105, 35));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salvar (1).png"))); // NOI18N
        jButton_Guardar.setText("Guardar Venta");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 280, 105, 35));

        jButton_Ticket.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Ticket.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Ticket.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Ticket.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/lista.png"))); // NOI18N
        jButton_Ticket.setText("Generar Ticket");
        jButton_Ticket.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Ticket.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jButton_Ticket, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 280, 105, 35));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("REGISTRO VENTAS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 230, 20));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("INGRESE LOS DATOS SOLICITADOS");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 130, 190, 10));
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new ingreso().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    private void jComboBox_CodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_CodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_CodigoActionPerformed

    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton_GuardarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new empleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Agregar;
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JButton jButton_Ticket;
    private javax.swing.JComboBox<String> jComboBox_Codigo;
    private javax.swing.JLabel jLabel_Cantidad;
    private javax.swing.JLabel jLabel_Codigo;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_PrecioU;
    private javax.swing.JLabel jLabel_Producto;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Factura;
    private javax.swing.JTextField jTextField_Cantidad;
    private javax.swing.JTextField jTextField_PrecioU;
    private javax.swing.JTextField jTextField_Producto;
    // End of variables declaration//GEN-END:variables
}
